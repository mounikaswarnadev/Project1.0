// const dbconn = require('mssql');

// var config = {
//     user: 'RajeshD',
//     password: 'ArtemisRajesh2021',
//     database: 'Artemis Master Database',
//     server: 'tcp:inventory.public.ec670bc17eaf.database.windows.net',
//     port:3342,
//    options:{
//        trustedconnection: true,
//        enableArithAbort: true,
//        instancename: ""
//    }
   
// };

// // const conn = new mysql.createConnection(config);
// // const conn = mysql.connect(config);

// // mysql.on('error', err =>{
// //     console.log(err.message,'errmesga');
// // })

// // async function getDBdata(){
// //     try{
// //         let pool = await mysql.connect(config)
// //         let res1 = await pool.request().query('select * from dbo.Applications');
// //         console.log(res1,'res');
// //     } catch(error){

// //     }
// // }
// // getDBdata();

// // mw
// module.exports = config;
 