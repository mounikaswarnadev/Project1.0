const config = {
  user :'RajeshD',
  password :'ArtemisRajesh2021',
  server:'artemis-inventory.public.ec670bc17eaf.database.windows.net',
  database:'Artemis Master Database',
  options:{
      trustedconnection: true,
      enableArithAbort : true,
  },
  port : 3342
}

module.exports = config;
